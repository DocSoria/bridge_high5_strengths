# Bridge HIGH5 Strengths

Interactive strengths-discovery learning activities developed for the University of Idaho Bridge training program.

## Current activity

**Strengths Leave Clues** is an interactive reflection activity that invites learners to examine everyday workplace scenarios, choose the response that feels most natural, and consider what those patterns may suggest about how they think, work, relate, and contribute.

The activity is designed to complement the HIGH5 strengths assessment. It is **not** a diagnostic tool and does not assign strengths based on a learner's scenario choices.

## Accessibility

The current prototype includes:

- keyboard-accessible controls;
- visible focus states;
- high-contrast text and interface elements;
- minimum touch-target sizing;
- responsive layouts for smaller screens;
- reduced-motion support;
- semantic form controls and status messages.

## Brand palette

The interface draws from University of Idaho brand colors, with emphasis on:

- Silver: `#808080`
- Palouse: `#034441`
- Bark: `#552301`
- Huckleberry: `#261882`

## Files

- `index.html` — the complete interactive activity

## GitHub Pages

This site can be published directly with GitHub Pages from the repository's `main` branch and root directory.

---
Prototype for Bridge training.
